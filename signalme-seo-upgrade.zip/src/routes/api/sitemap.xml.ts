/**
 * DYNAMIC SITEMAP — /sitemap.xml
 *
 * Replaces the static public/sitemap.xml with a server-rendered
 * version that includes ALL programmatic location pages:
 *
 *   /rent                           (1)
 *   /rent/$state                    (39 states)
 *   /rent/$state/$type              (39 × 10 = 390)
 *   Static pages                    (6)
 *
 *   Total: ~436 URLs
 *
 * Deploy note: In Cloudflare Workers / TanStack Start, this
 * API route runs server-side and returns the correct
 * Content-Type: application/xml header.
 *
 * IMPORTANT: after adding this file, delete or empty
 * public/sitemap.xml so Google doesn't see two sitemaps.
 * Keep robots.txt pointing to https://signalme.app/sitemap.xml
 */

import { createAPIFileRoute } from "@tanstack/react-start/api";

const SITE_URL = "https://signalme.app";

const STATE_SLUGS: Record<string, string> = {
  "lagos": "Lagos",
  "abuja": "FCT - Abuja",
  "port-harcourt": "Rivers",
  "ibadan": "Oyo",
  "kano": "Kano",
  "enugu": "Enugu",
  "benin-city": "Edo",
  "uyo": "Akwa Ibom",
  "kaduna": "Kaduna",
  "jos": "Plateau",
  "abia": "Abia",
  "adamawa": "Adamawa",
  "akwa-ibom": "Akwa Ibom",
  "anambra": "Anambra",
  "bauchi": "Bauchi",
  "bayelsa": "Bayelsa",
  "benue": "Benue",
  "borno": "Borno",
  "cross-river": "Cross River",
  "delta": "Delta",
  "ebonyi": "Ebonyi",
  "edo": "Edo",
  "ekiti": "Ekiti",
  "gombe": "Gombe",
  "imo": "Imo",
  "jigawa": "Jigawa",
  "katsina": "Katsina",
  "kebbi": "Kebbi",
  "kogi": "Kogi",
  "kwara": "Kwara",
  "nasarawa": "Nasarawa",
  "niger": "Niger",
  "ogun": "Ogun",
  "ondo": "Ondo",
  "osun": "Osun",
  "sokoto": "Sokoto",
  "taraba": "Taraba",
  "yobe": "Yobe",
  "zamfara": "Zamfara",
};

const TYPE_SLUGS = [
  "selfcon",
  "1-room",
  "room-and-parlour",
  "2-bedroom-flat",
  "3-bedroom-flat",
  "duplex",
  "shop",
  "office",
  "warehouse",
  "hall",
];

// Static pages that should be indexed
const STATIC_PAGES = [
  { loc: "/", changefreq: "daily", priority: "1.0" },
  { loc: "/about", changefreq: "monthly", priority: "0.8" },
  { loc: "/plans", changefreq: "weekly", priority: "0.9" },
  { loc: "/contact", changefreq: "monthly", priority: "0.6" },
  { loc: "/privacy", changefreq: "yearly", priority: "0.3" },
  { loc: "/terms", changefreq: "yearly", priority: "0.3" },
  { loc: "/rent", changefreq: "weekly", priority: "0.9" },
];

function url(
  loc: string,
  changefreq: string,
  priority: string,
  lastmod?: string
): string {
  const today = lastmod ?? new Date().toISOString().split("T")[0];
  return `  <url>
    <loc>${SITE_URL}${loc}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`;
}

export const APIRoute = createAPIFileRoute("/sitemap.xml")({
  GET: () => {
    const today = new Date().toISOString().split("T")[0];
    const urls: string[] = [];

    // Static pages
    for (const page of STATIC_PAGES) {
      urls.push(url(page.loc, page.changefreq, page.priority, today));
    }

    // State hub pages — /rent/$state
    for (const stateSlug of Object.keys(STATE_SLUGS)) {
      urls.push(url(`/rent/${stateSlug}`, "weekly", "0.8", today));
    }

    // Location+type pages — /rent/$state/$type
    for (const stateSlug of Object.keys(STATE_SLUGS)) {
      for (const typeSlug of TYPE_SLUGS) {
        urls.push(url(`/rent/${stateSlug}/${typeSlug}`, "weekly", "0.7", today));
      }
    }

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join("\n")}
</urlset>`;

    return new Response(xml, {
      status: 200,
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=3600, s-maxage=3600",
      },
    });
  },
});
